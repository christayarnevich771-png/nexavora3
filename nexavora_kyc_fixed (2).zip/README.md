<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/5828aa99-84de-4c73-9378-2ca9540852a5

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## KYC / Didit production setup

1. Run Supabase migrations in order, including `supabase/migrations/0004_kyc.sql`.
2. Create the private `kyc-documents` storage bucket via that migration (do not make it public).
3. Configure server-only environment variables:

```bash
NEXT_PUBLIC_SITE_URL=https://YOUR_DOMAIN
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
DIDIT_API_KEY=...
DIDIT_WEBHOOK_SECRET=...
```

Never put `DIDIT_API_KEY`, `DIDIT_WEBHOOK_SECRET`, or `SUPABASE_SERVICE_ROLE_KEY` in a `NEXT_PUBLIC_*` variable or client component.

4. In Didit, use workflow `5a5d6e4f-9a5a-4922-b1b8-949a0209d097` for the KYC session route.
5. Register a public HTTPS webhook destination pointing to:

```text
https://YOUR_DOMAIN/api/webhooks/didit
```

Use webhook version `v3` and subscribe to `status.updated` and `data.updated`. Store the returned signing secret as `DIDIT_WEBHOOK_SECRET`.
6. Give the intended administrator account `admin` (or `moderator`) role in `public.profiles` after signup:

```sql
update public.profiles
set role = 'admin'
where id = 'AUTH_USER_UUID';
```

The admin page now reads KYC records from Supabase, not browser localStorage. Uploaded government documents are private storage objects and are displayed to admins through short-lived signed URLs.
