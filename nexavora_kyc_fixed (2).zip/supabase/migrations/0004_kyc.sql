-- Persistent KYC intake, Didit webhook history, and private document storage.

create table if not exists public.kyc_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  full_name text not null,
  email text not null default '',
  date_of_birth date,
  country text,
  country_code text,
  document_type text not null,
  document_number text not null,
  document_expiry date,
  front_storage_path text,
  back_storage_path text,
  live_face_storage_path text,
  live_face_captured boolean not null default false,
  source text not null default 'in_app',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  didit_session_id text unique,
  didit_status text,
  didit_workflow_id text,
  didit_decision jsonb,
  didit_payload jsonb,
  rejection_reason text,
  admin_notes text,
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists kyc_submissions_user_id_idx on public.kyc_submissions(user_id, created_at desc);
create index if not exists kyc_submissions_status_idx on public.kyc_submissions(status, created_at desc);
create index if not exists kyc_submissions_didit_session_idx on public.kyc_submissions(didit_session_id);

create table if not exists public.kyc_audit_logs (
  id uuid primary key default gen_random_uuid(),
  submission_id uuid not null references public.kyc_submissions(id) on delete cascade,
  action text not null,
  performed_by uuid references public.profiles(id) on delete set null,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists kyc_audit_logs_submission_idx on public.kyc_audit_logs(submission_id, created_at desc);

create table if not exists public.didit_webhook_events (
  event_id text primary key,
  webhook_type text not null default '',
  session_id text not null default '',
  status text,
  payload jsonb not null,
  received_at timestamptz not null default now()
);

alter table public.kyc_submissions enable row level security;
alter table public.kyc_audit_logs enable row level security;
alter table public.didit_webhook_events enable row level security;

create policy "Users can view their own KYC submissions"
  on public.kyc_submissions for select
  using (user_id = auth.uid() or public.is_admin());

create policy "Admins can manage KYC submissions"
  on public.kyc_submissions for all
  using (public.is_admin())
  with check (public.is_admin());

create policy "Users can create their own KYC submission"
  on public.kyc_submissions for insert
  with check (user_id = auth.uid());

create policy "Users can view their own KYC audit entries"
  on public.kyc_audit_logs for select
  using (
    exists (
      select 1 from public.kyc_submissions s
      where s.id = submission_id and (s.user_id = auth.uid() or public.is_admin())
    )
  );

create policy "Admins can manage KYC audit entries"
  on public.kyc_audit_logs for all
  using (public.is_admin())
  with check (public.is_admin());

-- Webhook events are written by the service role only.

create trigger kyc_submissions_updated_at
  before update on public.kyc_submissions
  for each row execute function public.set_updated_at();

insert into storage.buckets (id, name, public)
values ('kyc-documents', 'kyc-documents', false)
on conflict (id) do update set public = false;

create policy "Users can upload their KYC files"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'kyc-documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Users can view their KYC files"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'kyc-documents'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
  );

create policy "Admins can manage KYC files"
  on storage.objects for all
  to authenticated
  using (bucket_id = 'kyc-documents' and public.is_admin())
  with check (bucket_id = 'kyc-documents' and public.is_admin());
