export type DocumentType = "nid" | "passport" | "driving_license";
export type KYCStatus = "unverified" | "pending" | "approved" | "rejected";

/**
 * Shared KYC types. Actual submissions are persisted through /api/kyc and
 * /api/admin/kyc; browser localStorage is intentionally not used for KYC data.
 */
export interface KYCSubmission {
  id: string;
  userId: string;
  fullName: string;
  email: string;
  dateOfBirth: string;
  country: string;
  countryCode: string;
  documentType: DocumentType;
  documentNumber: string;
  documentExpiry: string;
  frontImage: string;
  backImage?: string;
  selfieImage: string;
  liveFaceDetected?: boolean;
  status: "pending" | "approved" | "rejected";
  submittedAt: string;
  reviewedAt?: string | null;
  reviewedBy?: string | null;
  reviewerRole?: string | null;
  rejectionReason?: string | null;
  adminNotes?: string | null;
}

export interface KYCAuditLogEntry {
  id: string;
  submissionId: string;
  applicantName: string;
  applicantEmail: string;
  action: "approved" | "rejected" | "reset_to_pending" | "submitted";
  performedBy: string;
  officerRole: string;
  timestamp: string;
  reasonOrNotes?: string;
  documentType: DocumentType;
  documentNumber: string;
  ipAddress?: string;
}

// Kept only for legacy activity/export code. It intentionally contains no
// fake applicants and is not the source of truth for KYC.
export function getStoredSubmissions(): KYCSubmission[] {
  return [];
}

export function getStoredAuditLogs(): KYCAuditLogEntry[] {
  return [];
}
