"use client";

import * as React from "react";
import Link from "next/link";
import {
  ShieldCheck,
  CreditCard,
  FileText,
  UploadCloud,
  CheckCircle2,
  ArrowRight,
  Clock,
  Lock,
  XCircle,
  Camera,
  RefreshCw,
  Video,
  UserCheck,
  Globe,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createClient } from "@/lib/supabase/client";
import type { DocumentType } from "@/lib/kyc-store";

type Submission = {
  id: string;
  status: "pending" | "approved" | "rejected";
  full_name: string;
  email: string;
  document_type: string;
  document_number: string;
  rejection_reason: string | null;
  didit_session_id: string | null;
  didit_status: string | null;
  source: string;
  live_face_captured: boolean;
  created_at: string;
};

const COUNTRIES = [
  ["BD", "🇧🇩 Bangladesh"],
  ["US", "🇺🇸 United States"],
  ["GB", "🇬🇧 United Kingdom"],
  ["CA", "🇨🇦 Canada"],
  ["DE", "🇩🇪 Germany"],
  ["AU", "🇦🇺 Australia"],
  ["FR", "🇫🇷 France"],
  ["JP", "🇯🇵 Japan"],
  ["SG", "🇸🇬 Singapore"],
  ["IN", "🇮🇳 India"],
  ["AE", "🇦🇪 United Arab Emirates"],
];

export default function KYCVerificationPage() {
  const supabase = React.useMemo(() => createClient(), []);
  const [status, setStatus] = React.useState<"unverified" | "pending" | "approved" | "rejected">("unverified");
  const [submission, setSubmission] = React.useState<Submission | null>(null);
  const [fullName, setFullName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [dob, setDob] = React.useState("");
  const [countryCode, setCountryCode] = React.useState("BD");
  const [documentType, setDocumentType] = React.useState<DocumentType>("nid");
  const [documentNumber, setDocumentNumber] = React.useState("");
  const [documentExpiry, setDocumentExpiry] = React.useState("");
  const [frontFile, setFrontFile] = React.useState<File | null>(null);
  const [backFile, setBackFile] = React.useState<File | null>(null);
  const [liveFaceFile, setLiveFaceFile] = React.useState<File | null>(null);
  const [frontPreview, setFrontPreview] = React.useState<string | null>(null);
  const [backPreview, setBackPreview] = React.useState<string | null>(null);
  const [liveFacePreview, setLiveFacePreview] = React.useState<string | null>(null);
  const [cameraActive, setCameraActive] = React.useState(false);
  const [cameraError, setCameraError] = React.useState<string | null>(null);
  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [diditLoading, setDiditLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [notice, setNotice] = React.useState<string | null>(null);

  const loadStatus = React.useCallback(async () => {
    const res = await fetch("/api/kyc", { cache: "no-store" });
    if (res.status === 401) return;
    if (!res.ok) return;
    const data = await res.json();
    const current = data.submission as Submission | null;
    setSubmission(current);
    setStatus(current?.status || "unverified");
  }, []);

  React.useEffect(() => {
    let mounted = true;
    void supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      if (data.user?.email) setEmail(data.user.email);
      const displayName = data.user?.user_metadata?.display_name || data.user?.user_metadata?.full_name;
      if (displayName) setFullName(displayName);
    });
    void loadStatus();

    const params = new URLSearchParams(window.location.search);
    if (params.get("didit_return") === "1") {
      setNotice("Didit has returned you to NEXAVORA. The verified webhook is now being checked; this page will not mark approval from the redirect alone.");
      void loadStatus();
    }

    return () => {
      mounted = false;
      stopCamera();
    };
  }, [loadStatus, supabase]);

  React.useEffect(() => {
    if (!submission || status === "approved" || status === "rejected") return;
    const timer = window.setInterval(() => void loadStatus(), 4000);
    return () => window.clearInterval(timer);
  }, [loadStatus, submission, status]);

  function stopCamera() {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraActive(false);
  }

  async function startCamera() {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("This browser does not support camera access.");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      setCameraActive(true);
      requestAnimationFrame(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play();
        }
      });
    } catch (e: any) {
      setCameraError(e?.message || "Camera permission was denied.");
    }
  }

  function captureLiveFace() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) {
      setCameraError("Camera is not ready yet. Please wait a moment and try again.");
      return;
    }
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], `live-face-${Date.now()}.jpg`, { type: "image/jpeg" });
      setLiveFaceFile(file);
      setLiveFacePreview(URL.createObjectURL(file));
      setNotice("Live face capture completed. It will be stored with this KYC submission for review.");
      stopCamera();
    }, "image/jpeg", 0.92);
  }

  function chooseImage(file: File | null, type: "front" | "back") {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please select an image file.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError("Each KYC image must be 8MB or smaller.");
      return;
    }
    setError(null);
    const preview = URL.createObjectURL(file);
    if (type === "front") {
      setFrontFile(file);
      setFrontPreview(preview);
    } else {
      setBackFile(file);
      setBackPreview(preview);
    }
  }

  async function startDidit() {
    setError(null);
    setDiditLoading(true);
    try {
      const res = await fetch("/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.url) throw new Error(data?.detail || data?.message || "Didit could not create a verification session.");
      setNotice("Opening the secure Didit verification flow. Complete the document and live-face checks there.");
      window.location.assign(data.url);
    } catch (e: any) {
      setError(e?.message || "Unable to start Didit verification.");
      setDiditLoading(false);
    }
  }

  async function submitInApp() {
    setError(null);
    if (!fullName.trim() || !dob || !documentNumber.trim()) {
      setError("Complete your legal name, date of birth, and document number first.");
      return;
    }
    if (!frontFile) {
      setError("Upload the front/bio page of your government document.");
      return;
    }
    if (documentType !== "passport" && !backFile) {
      setError("Upload the back side of your NID or driver's license.");
      return;
    }
    if (!liveFaceFile) {
      setError("Live face verification is required. Open the camera and capture your face.");
      return;
    }

    setLoading(true);
    try {
      const form = new FormData();
      form.set("fullName", fullName.trim());
      form.set("email", email.trim());
      form.set("dateOfBirth", dob);
      form.set("countryCode", countryCode);
      form.set("country", COUNTRIES.find(([code]) => code === countryCode)?.[1]?.replace(/^\S+\s/, "") || countryCode);
      form.set("documentType", documentType);
      form.set("documentNumber", documentNumber.trim());
      form.set("documentExpiry", documentExpiry);
      form.set("front", frontFile);
      if (backFile) form.set("back", backFile);
      form.set("liveFace", liveFaceFile);

      const res = await fetch("/api/kyc", { method: "POST", body: form });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || "KYC submission failed.");

      setSubmission(data.submission);
      setStatus(data.submission.status);
      setNotice("KYC submitted successfully. Your documents are now in the server-side admin compliance queue.");
    } catch (e: any) {
      setError(e?.message || "KYC submission failed.");
    } finally {
      setLoading(false);
    }
  }

  function resetForm() {
    setSubmission(null);
    setStatus("unverified");
    setFrontFile(null);
    setBackFile(null);
    setLiveFaceFile(null);
    setFrontPreview(null);
    setBackPreview(null);
    setLiveFacePreview(null);
    setError(null);
  }

  return (
    <div className="container max-w-3xl py-12">
      <div className="space-y-2 border-b border-border pb-6">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-brand">
            <ShieldCheck className="h-4 w-4" /> Seller KYC
          </div>
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-mono font-bold uppercase border ${status === "approved" ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/10" : status === "rejected" ? "border-destructive/30 text-destructive bg-destructive/10" : status === "pending" ? "border-warning/30 text-warning bg-warning/10" : "border-border text-muted-foreground bg-secondary"}`}>
            {status}
          </span>
        </div>
        <h1 className="font-display text-3xl sm:text-4xl">Seller Identity Verification</h1>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Verify with a government document and a live face check. Didit is the hosted verification path; the in-app path sends uploaded evidence to the NEXAVORA admin compliance queue.
        </p>
      </div>

      {notice && (
        <div className="mt-4 rounded-lg border border-brand/40 bg-brand/10 p-3 text-xs text-foreground">{notice}</div>
      )}
      {error && (
        <div className="mt-4 rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-xs text-destructive">{error}</div>
      )}

      {status === "approved" && (
        <div className="mt-8 rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-7 w-7 text-emerald-400" />
            <div>
              <h2 className="font-display text-xl">Identity Verified</h2>
              <p className="text-xs text-muted-foreground">Seller verification is approved. You can create listings.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 rounded-lg border border-border bg-background/70 p-4 text-xs">
            <div><span className="block text-[10px] uppercase text-muted-foreground">Name</span><b>{submission?.full_name || fullName}</b></div>
            <div><span className="block text-[10px] uppercase text-muted-foreground">Document</span><b>{submission?.document_type || documentType}</b></div>
            <div><span className="block text-[10px] uppercase text-muted-foreground">Number</span><b className="font-mono">{submission?.document_number || documentNumber}</b></div>
            <div><span className="block text-[10px] uppercase text-muted-foreground">Source</span><b>{submission?.source === "didit" ? "Didit" : "NEXAVORA Admin Review"}</b></div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="brand" asChild><Link href="/create-listing">Create Listing <ArrowRight className="h-4 w-4 ml-1" /></Link></Button>
            <Button variant="outline" onClick={resetForm}><RefreshCw className="h-4 w-4 mr-1" /> Re-verify</Button>
          </div>
        </div>
      )}

      {status === "pending" && (
        <div className="mt-8 rounded-xl border border-warning/40 bg-warning/10 p-6 space-y-4">
          <div className="flex items-center gap-3"><Clock className="h-7 w-7 text-warning" /><div><h2 className="font-display text-xl">Verification Pending</h2><p className="text-xs text-muted-foreground">Your submission is waiting for the verified Didit webhook or admin review.</p></div></div>
          <div className="rounded-lg border border-border bg-background/70 p-4 text-xs space-y-1">
            <p><b>Applicant:</b> {submission?.full_name || fullName}</p>
            <p><b>Document:</b> {submission?.document_type || documentType}</p>
            {submission?.didit_status && <p><b>Didit status:</b> {submission.didit_status}</p>}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="brand" onClick={startDidit} disabled={diditLoading}>{diditLoading ? "Opening Didit…" : "Continue with Didit"}</Button>
            <Button variant="outline" onClick={() => void loadStatus()}>Refresh Status</Button>
          </div>
        </div>
      )}

      {status === "rejected" && (
        <div className="mt-8 rounded-xl border border-destructive/40 bg-destructive/10 p-6 space-y-4">
          <div className="flex items-center gap-3"><XCircle className="h-7 w-7 text-destructive" /><div><h2 className="font-display text-xl">Verification Rejected</h2><p className="text-xs text-muted-foreground">{submission?.rejection_reason || "Please correct the submitted information and try again."}</p></div></div>
          <Button variant="brand" onClick={resetForm}>Submit New Verification</Button>
        </div>
      )}

      {status === "unverified" && (
        <div className="mt-8 space-y-8">
          <section className="rounded-2xl border-2 border-brand/50 bg-gradient-to-br from-brand/10 via-card to-card p-6 shadow-lg space-y-4">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand text-brand-foreground"><Globe className="h-5 w-5" /></div>
              <div>
                <h2 className="font-display text-base font-semibold flex items-center gap-2">Verified by Didit 3rd Party Gateway <span className="rounded bg-brand/20 px-2 py-0.5 text-[10px] font-mono font-bold text-brand">RECOMMENDED</span></h2>
                <p className="text-xs text-muted-foreground mt-1">Hosted document OCR, liveness, face match and AML checks using your configured Didit workflow.</p>
              </div>
            </div>
            <Button type="button" variant="brand" size="lg" disabled={diditLoading} onClick={startDidit} className="w-full sm:w-auto">
              {diditLoading ? "Connecting to Didit…" : "Launch Didit Verification"}
            </Button>
            <p className="text-[11px] text-muted-foreground border-t border-border/70 pt-3">The API key stays on the server. Approval is accepted only from the signed Didit webhook.</p>
          </section>

          <div className="relative flex items-center justify-center"><div className="border-t border-border w-full" /><span className="bg-background px-3 text-xs uppercase font-mono text-muted-foreground absolute">Or submit to admin review</span></div>

          <section className="space-y-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg">1. Select Government Document</h2><span className="text-xs font-mono text-muted-foreground">Step 1 of 4</span></div>
            <div className="grid gap-3 sm:grid-cols-3">
              {([
                ["nid", "National ID (NID)", "Front + back"],
                ["passport", "International Passport", "Bio page"],
                ["driving_license", "Driver's License", "Front + back"],
              ] as const).map(([id, title, desc]) => {
                const selected = documentType === id;
                return <button key={id} type="button" onClick={() => setDocumentType(id)} className={`rounded-xl border p-4 text-left transition-all ${selected ? "border-brand bg-brand/10 ring-2 ring-brand" : "border-border bg-card hover:border-brand/50"}`}>
                  <div className="flex items-center justify-between"><span className={selected ? "text-brand" : "text-muted-foreground"}>{id === "passport" ? <FileText className="h-5 w-5" /> : <CreditCard className="h-5 w-5" />}</span>{selected && <span className="text-[9px] font-bold text-brand">SELECTED</span>}</div>
                  <span className="mt-2 block font-display text-sm">{title}</span><span className="mt-1 block text-[11px] text-muted-foreground">{desc}</span>
                </button>;
              })}
            </div>
          </section>

          <section className="space-y-4 border-t border-border pt-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg">2. Official Legal Details</h2><span className="text-xs font-mono text-muted-foreground">Step 2 of 4</span></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5"><Label htmlFor="country">Issuing Country</Label><select id="country" value={countryCode} onChange={(e) => setCountryCode(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">{COUNTRIES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}</select></div>
              <div className="space-y-1.5"><Label htmlFor="fullName">Full Legal Name</Label><Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required /></div>
              <div className="space-y-1.5"><Label htmlFor="dob">Date of Birth</Label><Input id="dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} required /></div>
              <div className="space-y-1.5"><Label htmlFor="documentNumber">{documentType === "nid" ? "NID Number" : documentType === "passport" ? "Passport Number" : "Driver's License Number"}</Label><Input id="documentNumber" value={documentNumber} onChange={(e) => setDocumentNumber(e.target.value)} required /></div>
              <div className="space-y-1.5"><Label htmlFor="documentExpiry">Document Expiry</Label><Input id="documentExpiry" type="date" value={documentExpiry} onChange={(e) => setDocumentExpiry(e.target.value)} /></div>
              <div className="space-y-1.5"><Label htmlFor="email">Email</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            </div>
          </section>

          <section className="space-y-4 border-t border-border pt-6">
            <div className="flex items-center justify-between"><h2 className="font-display text-lg">3. High-Resolution Document Photos</h2><span className="text-xs font-mono text-muted-foreground">Step 3 of 4</span></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <UploadCard title={documentType === "passport" ? "Passport Bio Page" : "Document Front Side"} file={frontFile} preview={frontPreview} onChange={(f) => chooseImage(f, "front")} required />
              {documentType !== "passport" ? <UploadCard title="Document Back Side" file={backFile} preview={backPreview} onChange={(f) => chooseImage(f, "back")} required /> : <div className="rounded-xl border border-border bg-card p-5 text-xs text-muted-foreground">Passport bio page is sufficient for this in-app intake. Any additional pages can be reviewed through the Didit workflow.</div>}
            </div>
          </section>

          <section className="space-y-4 border-t border-border pt-6">
            <div className="flex items-center justify-between"><div><h2 className="font-display text-lg flex items-center gap-2"><UserCheck className="h-5 w-5 text-brand" />4. Live Face Verification</h2><p className="text-xs text-muted-foreground mt-1">Camera capture only — the selfie-file upload option has been removed.</p></div><span className="text-xs font-mono text-muted-foreground">Step 4 of 4</span></div>
            <div className="rounded-xl border border-border bg-card p-5">
              {cameraActive ? <div className="space-y-3"><div className="relative mx-auto max-w-xl overflow-hidden rounded-xl border-2 border-brand bg-black"><video ref={videoRef} autoPlay playsInline muted className="aspect-video w-full object-cover scale-x-[-1]" /><div className="pointer-events-none absolute inset-8 rounded-full border-2 border-dashed border-white/60" /></div><div className="flex justify-center gap-2"><Button variant="brand" type="button" onClick={captureLiveFace}><Camera className="h-4 w-4 mr-1.5" /> Capture Live Face</Button><Button type="button" variant="ghost" onClick={stopCamera}>Cancel</Button></div></div> : <div className="grid gap-4 sm:grid-cols-[220px_1fr] items-center"><div className="aspect-square overflow-hidden rounded-xl border border-dashed border-border bg-secondary/40 flex items-center justify-center">{liveFacePreview ? <img src={liveFacePreview} alt="Live face capture preview" className="h-full w-full object-cover" /> : <Video className="h-10 w-10 text-muted-foreground" />}</div><div className="space-y-3"><p className="text-xs text-muted-foreground">Allow camera access, center your face in the guide, and capture one clear live frame.</p><Button type="button" variant="outline" onClick={startCamera} className="w-full sm:w-auto"><Video className="h-4 w-4 mr-1.5 text-brand" /> Open Web Camera</Button>{cameraError && <p className="text-xs text-destructive">{cameraError}</p>}{liveFaceFile && <p className="text-xs text-emerald-400">Live face capture ready for upload.</p>}</div></div>}
            </div>
          </section>

          <div className="rounded-lg bg-secondary/40 p-4 border border-border text-xs text-muted-foreground"><p className="font-medium text-foreground flex items-center gap-1.5"><Lock className="h-3.5 w-3.5 text-brand" /> Private KYC storage</p><p className="mt-1">Documents are stored in a private Supabase Storage bucket. Admins receive signed temporary viewing links; files are not stored in browser localStorage.</p></div>

          <Button type="button" variant="brand" size="lg" disabled={loading} onClick={() => void submitInApp()} className="w-full">{loading ? <><UploadCloud className="h-4 w-4 mr-2 animate-pulse" /> Uploading secure KYC package…</> : <><UploadCloud className="h-4 w-4 mr-2" /> Submit to Compliance Review Queue</>}</Button>
          <p className="text-center text-[11px] text-muted-foreground"><ExternalLink className="inline h-3 w-3 mr-1" />For automated KYC/AML and liveness, use the Didit button above.</p>
        </div>
      )}
    </div>
  );
}

function UploadCard({ title, file, preview, onChange, required }: { title: string; file: File | null; preview: string | null; onChange: (file: File | null) => void; required?: boolean }) {
  return <div className="rounded-xl border border-border bg-card p-4 space-y-3"><div className="flex items-center justify-between text-xs"><span className="font-medium">{title}</span><span className={`text-[10px] uppercase font-mono font-bold ${required ? "text-brand" : "text-muted-foreground"}`}>{required ? "Required" : "Optional"}</span></div><div className="aspect-[16/10] overflow-hidden rounded-lg border border-dashed border-border bg-secondary/30 flex items-center justify-center">{preview ? <img src={preview} alt={`${title} preview`} className="h-full w-full object-cover" /> : <UploadCloud className="h-8 w-8 text-muted-foreground" />}</div><label className="flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-md border border-brand/50 bg-brand/5 py-2 text-center text-xs font-medium text-brand hover:bg-brand/10"><UploadCloud className="h-4 w-4" /> {file ? "Replace Photo" : "Upload Photo"}<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => onChange(e.target.files?.[0] || null)} /></label></div>;
}
