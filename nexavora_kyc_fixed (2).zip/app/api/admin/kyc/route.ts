import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const BUCKET = "kyc-documents";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Response(JSON.stringify({ error: "unauthorized" }), { status: 401 });

  const admin = createAdminClient();
  const { data: profile, error } = await admin
    .from("profiles")
    .select("id, role, display_name, username")
    .eq("id", auth.user.id)
    .single();

  if (error || !profile || !["admin", "moderator"].includes(profile.role)) {
    throw new Response(JSON.stringify({ error: "forbidden" }), { status: 403 });
  }
  return { user: auth.user, profile, admin };
}

async function signedUrl(admin: ReturnType<typeof createAdminClient>, path: string | null) {
  if (!path) return null;
  const { data } = await admin.storage.from(BUCKET).createSignedUrl(path, 60 * 15);
  return data?.signedUrl || null;
}

export async function GET() {
  try {
    const { admin } = await requireAdmin();
    const { data, error } = await admin
      .from("kyc_submissions")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;

    const submissions = await Promise.all(
      (data || []).map(async (item) => ({
        ...item,
        front_url: await signedUrl(admin, item.front_storage_path),
        back_url: await signedUrl(admin, item.back_storage_path),
        live_face_url: await signedUrl(admin, item.live_face_storage_path),
      })),
    );

    const { data: auditLogs, error: auditError } = await admin
      .from("kyc_audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    if (auditError) throw auditError;

    return NextResponse.json({ submissions, auditLogs });
  } catch (error: any) {
    if (error instanceof Response) return error;
    console.error("[Admin KYC GET]", error);
    return NextResponse.json({ error: error?.message || "Unable to load KYC queue." }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { user, profile, admin } = await requireAdmin();
    const body = await req.json();
    const id = String(body.id || "");
    const status = String(body.status || "");
    const rejectionReason = body.rejectionReason ? String(body.rejectionReason) : null;

    if (!id || !["pending", "approved", "rejected"].includes(status)) {
      return NextResponse.json({ error: "Invalid KYC update." }, { status: 400 });
    }

    const { data: submission, error: readError } = await admin
      .from("kyc_submissions")
      .select("id,user_id,full_name")
      .eq("id", id)
      .single();
    if (readError || !submission) return NextResponse.json({ error: "KYC submission not found." }, { status: 404 });

    const { data: updated, error } = await admin
      .from("kyc_submissions")
      .update({
        status: status as "pending" | "approved" | "rejected",
        rejection_reason: status === "rejected" ? rejectionReason : null,
        reviewed_at: status === "pending" ? null : new Date().toISOString(),
        reviewed_by: status === "pending" ? null : user.id,
      })
      .eq("id", id)
      .select("*")
      .single();
    if (error) throw error;

    await admin
      .from("profiles")
      .update({ is_verified: status === "approved" })
      .eq("id", submission.user_id);

    await admin.from("kyc_audit_logs").insert({
      submission_id: id,
      action: status,
      performed_by: user.id,
      note:
        status === "rejected"
          ? rejectionReason || "Rejected by compliance officer."
          : status === "approved"
            ? `Approved by ${profile.display_name || profile.username}.`
            : "Returned to pending review.",
    });

    return NextResponse.json({ submission: updated });
  } catch (error: any) {
    if (error instanceof Response) return error;
    console.error("[Admin KYC PATCH]", error);
    return NextResponse.json({ error: error?.message || "Unable to update KYC." }, { status: 500 });
  }
}
