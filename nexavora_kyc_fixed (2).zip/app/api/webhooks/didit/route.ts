import crypto from "node:crypto";
import { NextRequest } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

function shortenFloats(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(shortenFloats);
  if (v && typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, shortenFloats(x)]),
    );
  }
  if (typeof v === "number" && !Number.isInteger(v) && v % 1 === 0) return Math.trunc(v);
  return v;
}

function sortKeys(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(sortKeys);
  if (v && typeof v === "object") {
    return Object.keys(v as object)
      .sort()
      .reduce<Record<string, unknown>>((acc, k) => {
        acc[k] = sortKeys((v as Record<string, unknown>)[k]);
        return acc;
      }, {});
  }
  return v;
}

export async function POST(req: NextRequest) {
  try {
    const raw = await req.text();
    const signature = req.headers.get("x-signature-v2") || "";
    const timestamp = Number(req.headers.get("x-timestamp"));
    const secret = process.env.DIDIT_WEBHOOK_SECRET;

    if (!secret) return new Response("webhook not configured", { status: 500 });
    if (!timestamp || Math.abs(Date.now() / 1000 - timestamp) > 300) {
      return new Response("stale", { status: 401 });
    }
    if (!signature) return new Response("missing signature", { status: 401 });

    const parsed = JSON.parse(raw) as Record<string, any>;
    const canonical = JSON.stringify(sortKeys(shortenFloats(parsed)));
    const expected = crypto.createHmac("sha256", secret).update(canonical, "utf8").digest("hex");

    if (
      signature.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(expected, "utf8"), Buffer.from(signature, "utf8"))
    ) {
      return new Response("bad sig", { status: 401 });
    }

    const admin = createAdminClient();
    const eventId = String(parsed.event_id || "");
    if (!eventId) return new Response("missing event_id", { status: 400 });

    const { error: eventError } = await admin.from("didit_webhook_events").insert({
      event_id: eventId,
      webhook_type: String(parsed.webhook_type || ""),
      session_id: String(parsed.session_id || ""),
      status: parsed.status ? String(parsed.status) : null,
      payload: parsed,
    });
    if (eventError?.code === "23505") return new Response("ok");
    if (eventError) throw eventError;

    const sessionId = String(parsed.session_id || "");
    const vendorData = String(parsed.vendor_data || "");
    const status = String(parsed.status || "");
    if (!sessionId) return new Response("ok");

    const { data: kyc } = await admin
      .from("kyc_submissions")
      .select("id,user_id")
      .eq("didit_session_id", sessionId)
      .maybeSingle();

    // A session can be created before the local record exists; the user can still
    // be matched by vendor_data when the webhook arrives.
    const userId = kyc?.user_id || vendorData || null;
    if (!userId) return new Response("ok");

    const mappedStatus = status
      ? status === "Approved"
        ? "approved"
        : status === "Declined" || status === "Kyc Expired"
          ? "rejected"
          : "pending"
      : null;

    if (kyc) {
      await admin
        .from("kyc_submissions")
        .update({
          ...(mappedStatus ? { status: mappedStatus } : {}),
          didit_status: status || null,
          didit_decision: parsed.decision ?? null,
          didit_payload: parsed,
          ...(mappedStatus === "approved" || mappedStatus === "rejected" ? { reviewed_at: new Date().toISOString() } : {}),
          ...(status === "Declined" ? { rejection_reason: "Didit declined the verification." } : {}),
        })
        .eq("id", kyc.id);
    } else {
      await admin.from("kyc_submissions").insert({
        user_id: userId,
        didit_session_id: sessionId,
        didit_workflow_id: parsed.workflow_id ? String(parsed.workflow_id) : null,
        didit_status: status || null,
        didit_decision: parsed.decision ?? null,
        didit_payload: parsed,
        status: mappedStatus || "pending",
        full_name: String(parsed.metadata?.applicant_name || "Didit applicant"),
        email: String(parsed.metadata?.applicant_email || ""),
        document_type: "didit_workflow",
        document_number: "pending_didit",
        source: "didit",
        submitted_at: new Date().toISOString(),
        reviewed_at: mappedStatus === "approved" || mappedStatus === "rejected" ? new Date().toISOString() : null,
      });
    }

    if (mappedStatus === "approved") {
      await admin.from("profiles").update({ is_verified: true }).eq("id", userId);
    } else if (mappedStatus === "rejected") {
      await admin.from("profiles").update({ is_verified: false }).eq("id", userId);
    }

    return new Response("ok", { status: 200 });
  } catch (error) {
    console.error("[Didit webhook error]", error);
    return new Response("webhook processing error", { status: 500 });
  }
}
