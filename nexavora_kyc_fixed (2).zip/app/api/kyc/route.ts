import crypto from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const BUCKET = "kyc-documents";
const MAX_FILE_SIZE = 8 * 1024 * 1024;

function validateImage(file: File | null, label: string, required = true) {
  if (!file || file.size === 0) {
    if (required) throw new Error(`${label} is required.`);
    return;
  }
  if (!file.type.startsWith("image/")) throw new Error(`${label} must be an image.`);
  if (file.size > MAX_FILE_SIZE) throw new Error(`${label} must be 8MB or smaller.`);
}

function ext(file: File) {
  const mime = file.type.toLowerCase();
  if (mime === "image/png") return "png";
  if (mime === "image/webp") return "webp";
  return "jpg";
}

export async function GET() {
  try {
    const supabase = await createClient();
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

    const admin = createAdminClient();
    const { data, error } = await admin
      .from("kyc_submissions")
      .select("id,status,full_name,email,document_type,document_number,rejection_reason,didit_session_id,didit_status,source,live_face_captured,created_at")
      .eq("user_id", auth.user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    return NextResponse.json({ submission: data });
  } catch (error: any) {
    console.error("[KYC GET]", error);
    return NextResponse.json({ error: error?.message || "Unable to load KYC status." }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: auth } = await supabase.auth.getUser();
    const user = auth.user;
    if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

    const form = await req.formData();
    const fullName = String(form.get("fullName") || "").trim();
    const email = String(form.get("email") || user.email || "").trim();
    const dateOfBirth = String(form.get("dateOfBirth") || "").trim() || null;
    const country = String(form.get("country") || "").trim() || null;
    const countryCode = String(form.get("countryCode") || "").trim() || null;
    const documentType = String(form.get("documentType") || "").trim();
    const documentNumber = String(form.get("documentNumber") || "").trim();
    const documentExpiry = String(form.get("documentExpiry") || "").trim() || null;
    const front = form.get("front") as File | null;
    const back = form.get("back") as File | null;
    const liveFace = form.get("liveFace") as File | null;

    if (!fullName || !documentType || !documentNumber) {
      return NextResponse.json({ error: "Full name, document type and document number are required." }, { status: 400 });
    }

    validateImage(front, "Front document photo");
    validateImage(back, "Back document photo", documentType !== "passport");
    validateImage(liveFace, "Live face capture");

    const admin = createAdminClient();
    const id = crypto.randomUUID();
    const prefix = `${user.id}/${id}`;
    const uploads: Record<string, string> = {};

    async function upload(file: File, name: string) {
      const path = `${prefix}/${name}.${ext(file)}`;
      const { error } = await admin.storage.from(BUCKET).upload(path, Buffer.from(await file.arrayBuffer()), {
        contentType: file.type || "image/jpeg",
        upsert: false,
      });
      if (error) throw error;
      uploads[name] = path;
    }

    await upload(front!, "front");
    if (back) await upload(back, "back");
    await upload(liveFace!, "live-face");

    const { data: submission, error } = await admin
      .from("kyc_submissions")
      .insert({
        id,
        user_id: user.id,
        full_name: fullName,
        email,
        date_of_birth: dateOfBirth,
        country,
        country_code: countryCode,
        document_type: documentType,
        document_number: documentNumber,
        document_expiry: documentExpiry,
        front_storage_path: uploads.front,
        back_storage_path: uploads.back || null,
        live_face_storage_path: uploads["live-face"],
        live_face_captured: true,
        source: "in_app",
        status: "pending",
      })
      .select("*")
      .single();

    if (error) throw error;

    await admin.from("kyc_audit_logs").insert({
      submission_id: id,
      action: "submitted",
      performed_by: user.id,
      note: "Seller submitted government document photos and a live face capture.",
    });

    return NextResponse.json({ submission }, { status: 201 });
  } catch (error: any) {
    console.error("[KYC POST]", error);
    return NextResponse.json({ error: error?.message || "KYC submission failed." }, { status: 500 });
  }
}
