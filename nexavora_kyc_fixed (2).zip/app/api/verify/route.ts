import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

// This is configuration, not a secret. It belongs in code/config, not .env.
const WORKFLOW_ID = "5a5d6e4f-9a5a-4922-b1b8-949a0209d097";

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    }

    const apiKey = process.env.DIDIT_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "didit_not_configured", message: "DIDIT_API_KEY is missing on the server." },
        { status: 500 },
      );
    }

    const body = await req.json().catch(() => ({}));
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || req.nextUrl.origin;
    const callbackUrl = `${siteUrl.replace(/\/$/, "")}/kyc?didit_return=1`;

    const res = await fetch("https://verification.didit.me/v3/session/", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        workflow_id: WORKFLOW_ID,
        vendor_data: user.id,
        callback: callbackUrl,
        callback_method: "initiator",
        metadata: {
          platform: "NEXAVORA",
          applicant_name: String(body.fullName || user.user_metadata?.display_name || "").trim(),
          applicant_email: user.email || String(body.email || "").trim(),
        },
      }),
      cache: "no-store",
    });

    const raw = await res.text();
    let session: Record<string, unknown> = {};
    try {
      session = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      // Keep the raw response in the server log only.
    }

    if (!res.ok) {
      console.error("[Didit session error]", res.status, raw);
      return NextResponse.json(
        { error: "session_create_failed", detail: session.detail || raw || "Didit rejected the request." },
        { status: 502 },
      );
    }

    const url = typeof session.url === "string" ? session.url : null;
    const sessionId = typeof session.session_id === "string" ? session.session_id : null;

    if (!url || !sessionId) {
      console.error("[Didit session malformed]", raw);
      return NextResponse.json({ error: "invalid_didit_response" }, { status: 502 });
    }

    const admin = createAdminClient();
    const { error: persistError } = await admin.from("kyc_submissions").insert({
      user_id: user.id,
      full_name: String(body.fullName || user.user_metadata?.display_name || "Didit applicant").trim(),
      email: user.email || String(body.email || "").trim(),
      document_type: "didit_workflow",
      document_number: "pending_didit",
      source: "didit",
      status: "pending",
      didit_session_id: sessionId,
      didit_workflow_id: WORKFLOW_ID,
      didit_status: typeof session.status === "string" ? session.status : "Not Started",
    });

    if (persistError) {
      console.error("[Didit session DB persist error]", persistError);
      return NextResponse.json({ error: "kyc_persistence_failed" }, { status: 500 });
    }

    return NextResponse.json({ url, session_id: sessionId });
  } catch (error) {
    console.error("[Didit route exception]", error);
    return NextResponse.json({ error: "internal_server_error" }, { status: 500 });
  }
}
