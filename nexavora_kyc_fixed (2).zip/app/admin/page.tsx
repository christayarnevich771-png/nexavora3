"use client";

import * as React from "react";
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Eye,
  RefreshCw,
  Download,
  User,
  FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type AdminSubmission = {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  date_of_birth: string | null;
  country: string | null;
  country_code: string | null;
  document_type: string;
  document_number: string;
  document_expiry: string | null;
  status: "pending" | "approved" | "rejected";
  source: string;
  live_face_captured: boolean;
  didit_session_id: string | null;
  didit_status: string | null;
  didit_decision: unknown;
  rejection_reason: string | null;
  admin_notes: string | null;
  submitted_at: string;
  reviewed_at: string | null;
  front_url: string | null;
  back_url: string | null;
  live_face_url: string | null;
};

type AuditLog = { id: string; submission_id: string; action: string; performed_by: string | null; note: string | null; created_at: string };

export default function AdminPage() {
  const [submissions, setSubmissions] = React.useState<AdminSubmission[]>([]);
  const [auditLogs, setAuditLogs] = React.useState<AuditLog[]>([]);
  const [filter, setFilter] = React.useState<"all" | "pending" | "approved" | "rejected">("pending");
  const [search, setSearch] = React.useState("");
  const [selected, setSelected] = React.useState<AdminSubmission | null>(null);
  const [rejecting, setRejecting] = React.useState<AdminSubmission | null>(null);
  const [reason, setReason] = React.useState("Document image is unclear or the submitted information could not be verified.");
  const [loading, setLoading] = React.useState(true);
  const [savingId, setSavingId] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [notice, setNotice] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/kyc", { cache: "no-store" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || "You do not have access to the admin KYC queue.");
      setSubmissions(data.submissions || []);
      setAuditLogs(data.auditLogs || []);
    } catch (e: any) {
      setError(e?.message || "Unable to load the admin KYC queue.");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => { void load(); }, [load]);

  async function updateStatus(item: AdminSubmission, status: "approved" | "rejected" | "pending", rejectionReason?: string) {
    setSavingId(item.id);
    setError(null);
    try {
      const res = await fetch("/api/admin/kyc", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: item.id, status, rejectionReason }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || "Could not update KYC status.");
      setNotice(`${item.full_name}: ${status.toUpperCase()}`);
      setRejecting(null);
      setSelected(null);
      await load();
    } catch (e: any) {
      setError(e?.message || "Could not update KYC status.");
    } finally {
      setSavingId(null);
    }
  }

  const filtered = submissions.filter((item) => {
    const matchesStatus = filter === "all" || item.status === filter;
    const haystack = `${item.full_name} ${item.email} ${item.document_number} ${item.country || ""}`.toLowerCase();
    return matchesStatus && haystack.includes(search.toLowerCase());
  });

  function exportCsv() {
    const rows = filtered.map((x) => [x.id, x.full_name, x.email, x.country || "", x.document_type, x.document_number, x.status, x.source, x.submitted_at]);
    const csv = [["ID", "Name", "Email", "Country", "Document", "Document Number", "Status", "Source", "Submitted At"], ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nexavora-kyc-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand">Restricted Admin Area</p>
          <h1 className="mt-1 font-display text-3xl sm:text-4xl">Seller KYC Compliance Queue</h1>
          <p className="mt-1 text-sm text-muted-foreground">Real submissions from Supabase — not browser localStorage. Document images are private and shown through temporary signed URLs.</p>
        </div>
        <div className="flex gap-2"><Button variant="outline" onClick={() => void load()}><RefreshCw className="h-4 w-4 mr-1.5" /> Refresh</Button><Button variant="outline" onClick={exportCsv}><Download className="h-4 w-4 mr-1.5" /> CSV</Button></div>
      </div>

      {notice && <div className="mt-5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300">{notice}</div>}
      {error && <div className="mt-5 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">{error}</div>}

      <div className="mt-8 grid gap-3 sm:grid-cols-4">
        <Stat label="Total" value={submissions.length} icon={<FileText className="h-4 w-4" />} />
        <Stat label="Pending" value={submissions.filter((x) => x.status === "pending").length} icon={<Clock className="h-4 w-4" />} />
        <Stat label="Approved" value={submissions.filter((x) => x.status === "approved").length} icon={<CheckCircle2 className="h-4 w-4" />} />
        <Stat label="Rejected" value={submissions.filter((x) => x.status === "rejected").length} icon={<XCircle className="h-4 w-4" />} />
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">{(["pending", "all", "approved", "rejected"] as const).map((key) => <Button key={key} size="sm" variant={filter === key ? "brand" : "outline"} onClick={() => setFilter(key)} className="capitalize">{key}</Button>)}</div>
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search seller, email, document…" className="sm:max-w-xs" />
      </div>

      <div className="mt-4 overflow-x-auto rounded-xl border border-border bg-card">
        {loading ? <div className="p-10 text-center text-sm text-muted-foreground">Loading KYC queue…</div> : filtered.length === 0 ? <div className="p-10 text-center text-sm text-muted-foreground">No KYC submissions match this filter.</div> : <table className="w-full min-w-[900px] text-left text-xs"><thead className="border-b border-border bg-secondary/30"><tr><th className="px-4 py-3">Applicant</th><th className="px-4 py-3">Document</th><th className="px-4 py-3">Source</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Submitted</th><th className="px-4 py-3 text-right">Action</th></tr></thead><tbody className="divide-y divide-border">{filtered.map((item) => <tr key={item.id} className="hover:bg-secondary/20"><td className="px-4 py-4"><div className="font-semibold">{item.full_name}</div><div className="text-muted-foreground">{item.email}</div></td><td className="px-4 py-4"><div className="font-medium uppercase">{item.document_type}</div><div className="font-mono text-muted-foreground">{item.document_number}</div></td><td className="px-4 py-4"><span className="rounded bg-secondary px-2 py-1 uppercase">{item.source}</span>{item.didit_status && <div className="mt-1 text-muted-foreground">Didit: {item.didit_status}</div>}</td><td className="px-4 py-4"><StatusBadge status={item.status} /></td><td className="px-4 py-4 text-muted-foreground">{new Date(item.submitted_at).toLocaleString()}</td><td className="px-4 py-4 text-right"><Button size="sm" variant="outline" onClick={() => setSelected(item)}><Eye className="h-3.5 w-3.5 mr-1" /> Inspect</Button></td></tr>)}</tbody></table>}
      </div>

      <div className="mt-10 rounded-xl border border-border bg-card p-5"><h2 className="font-display text-lg">Audit Log</h2><div className="mt-3 space-y-2">{auditLogs.slice(0, 20).map((log) => <div key={log.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 border-b border-border/60 py-2 text-xs"><span className="font-mono uppercase">{log.action}</span><span className="text-muted-foreground">{log.note || ""}</span><span className="text-muted-foreground">{new Date(log.created_at).toLocaleString()}</span></div>)}{auditLogs.length === 0 && <p className="text-xs text-muted-foreground">No audit entries yet.</p>}</div></div>

      {selected && <InspectModal item={selected} saving={savingId === selected.id} onClose={() => setSelected(null)} onApprove={() => void updateStatus(selected, "approved")} onReject={() => setRejecting(selected)} />}
      {rejecting && <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4"><form onSubmit={(e) => { e.preventDefault(); void updateStatus(rejecting, "rejected", reason); }} className="w-full max-w-md rounded-xl border border-border bg-card p-6 space-y-4"><h2 className="font-display text-xl">Reject KYC</h2><p className="text-xs text-muted-foreground">{rejecting.full_name}</p><textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={4} className="w-full rounded-md border border-input bg-background p-3 text-sm" required /><div className="flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setRejecting(null)}>Cancel</Button><Button type="submit" variant="destructive" disabled={savingId === rejecting.id}>Confirm Rejection</Button></div></form></div>}
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) { return <div className="rounded-xl border border-border bg-card p-4"><div className="flex items-center justify-between text-xs text-muted-foreground"><span>{label}</span>{icon}</div><p className="mt-2 font-mono text-2xl font-bold">{value}</p></div>; }
function StatusBadge({ status }: { status: string }) { const cls = status === "approved" ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : status === "rejected" ? "text-destructive bg-destructive/10 border-destructive/20" : "text-warning bg-warning/10 border-warning/20"; return <span className={`rounded border px-2 py-1 text-[10px] font-mono font-bold uppercase ${cls}`}>{status}</span>; }

function InspectModal({ item, saving, onClose, onApprove, onReject }: { item: AdminSubmission; saving: boolean; onClose: () => void; onApprove: () => void; onReject: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"><div className="w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl border border-border bg-card p-6 shadow-2xl"><div className="flex items-start justify-between gap-4 border-b border-border pb-4"><div><p className="text-[10px] uppercase tracking-wider text-brand">KYC document inspection</p><h2 className="font-display text-2xl">{item.full_name}</h2><p className="text-xs text-muted-foreground">{item.country || item.country_code || ""} · {item.document_type} · {item.document_number}</p></div><Button variant="ghost" onClick={onClose}>Close</Button></div><div className="mt-5 grid gap-4 md:grid-cols-3"><ImagePanel title="Front / Bio Page" src={item.front_url} /><ImagePanel title="Back Side" src={item.back_url} /><ImagePanel title="Live Face Capture" src={item.live_face_url} /></div><div className="mt-5 grid gap-3 sm:grid-cols-2 rounded-lg border border-border bg-secondary/30 p-4 text-xs"><p><b>User ID:</b> <span className="font-mono">{item.user_id}</span></p><p><b>Email:</b> {item.email}</p><p><b>DOB:</b> {item.date_of_birth || "—"}</p><p><b>Expiry:</b> {item.document_expiry || "—"}</p><p><b>Source:</b> {item.source}</p><p><b>Didit session:</b> <span className="font-mono">{item.didit_session_id || "—"}</span></p><p><b>Didit status:</b> {item.didit_status || "—"}</p><p><b>Live face captured:</b> {item.live_face_captured ? "Yes" : "No"}</p></div>{item.rejection_reason && <div className="mt-4 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">{item.rejection_reason}</div>}<div className="mt-6 flex flex-wrap justify-end gap-2"><Button variant="outline" onClick={onClose}>Close</Button>{item.status !== "approved" && <Button variant="brand" onClick={onApprove} disabled={saving}><CheckCircle2 className="h-4 w-4 mr-1.5" /> Approve Seller</Button>}{item.status !== "rejected" && <Button variant="destructive" onClick={onReject} disabled={saving}><XCircle className="h-4 w-4 mr-1.5" /> Reject</Button>}</div></div></div>;
}
function ImagePanel({ title, src }: { title: string; src: string | null }) { return <div><p className="mb-2 text-xs font-semibold">{title}</p><div className="aspect-[4/3] overflow-hidden rounded-lg border border-border bg-black/30">{src ? <img src={src} alt={title} className="h-full w-full object-contain" /> : <div className="h-full flex items-center justify-center text-xs text-muted-foreground"><User className="h-4 w-4 mr-1" />Not provided</div>}</div></div>; }
